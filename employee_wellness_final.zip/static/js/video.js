// Video streaming functionality (placeholder)
document.addEventListener('DOMContentLoaded', function() {
    // This would typically set up video streaming using WebRTC
    // For now, we'll just display a placeholder message
    
    const videoFeed = document.querySelector('.video-feed');
    if (videoFeed) {
        // Simulate video streaming with a static message
        videoFeed.innerHTML = `
            <div style="text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 1rem;">📹</div>
                <p>Live Video Streaming</p>
                <p style="font-size: 0.8rem; margin-top: 1rem;">Video monitoring is active</p>
            </div>
        `;
    }
    
    // Timer functionality is now handled in the template
});